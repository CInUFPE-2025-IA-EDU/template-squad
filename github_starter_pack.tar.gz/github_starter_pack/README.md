# Template Stepped-Wedge (CIn-UFPE)
Use este template para os squads.
